struct dac_h {
	int nsamples;
	int freq;
};
