#include <stdlib.h>
#include <stdio.h>


/***********************************
Conversion utilities
************************************/

//void int2char (int in[],int len, char out []);
//void char2int(char in[], int len, int out []);
//void char2float(char in[], int len, float out []);
int readfile(char nombre[],char array[],int length_max);
void escribe_archivo(char nombre[],unsigned char data[], int length_max);
int cuenta_archivo(char nombre[]);

