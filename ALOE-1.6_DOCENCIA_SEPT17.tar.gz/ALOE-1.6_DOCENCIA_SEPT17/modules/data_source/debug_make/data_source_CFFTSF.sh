./data_source -p block_length=20000 plot_modeOUT=CFFTSF samplingfreqHz=48000.0 gain=2.0 tonefreq=327.0
