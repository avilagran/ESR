rm $HOME/.config/pulse/client.conf
pulseaudio --start
