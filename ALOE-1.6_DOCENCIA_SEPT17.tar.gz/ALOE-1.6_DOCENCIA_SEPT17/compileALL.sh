make clean
make
sudo make install
