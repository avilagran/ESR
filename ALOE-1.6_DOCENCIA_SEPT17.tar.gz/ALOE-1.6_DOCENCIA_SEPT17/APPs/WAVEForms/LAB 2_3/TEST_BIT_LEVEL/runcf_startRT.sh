./stop_runcf.sh
sudo runcf -c hwplatform/platform.conf
