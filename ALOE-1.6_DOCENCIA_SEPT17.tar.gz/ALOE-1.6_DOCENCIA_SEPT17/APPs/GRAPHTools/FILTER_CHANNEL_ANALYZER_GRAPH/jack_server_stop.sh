#!/bin/bash

jack_control exit

