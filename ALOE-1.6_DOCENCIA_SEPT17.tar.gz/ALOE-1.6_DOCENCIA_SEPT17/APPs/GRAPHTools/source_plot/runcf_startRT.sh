sudo pkill -9 runcf
sudo pkill -9 gnuplot
sudo runcf -f
sudo runcf -f
sudo runcf -c hwplatform/platform.conf
